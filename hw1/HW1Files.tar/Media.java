abstract class Media 
{
    protected String title;
	public String getTitle()  { return title; }
}
